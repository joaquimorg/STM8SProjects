

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H__
#define __MAIN_H__

#include "stm8s.h"

/* Exported functions ------------------------------------------------------- */
u8 GetVar_RxCounter1(void);
u8 IncrementVar_RxCounter1(void);
void SetVar_RxCounter1( u8 Counter );


#endif /* __MAIN_H__ */