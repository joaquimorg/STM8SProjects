//	
//		glib.c
//      
//      Copyright 2010 joaquim <mail@joaquim.org>
//      
//      This program is free software; you can redistribute it and/or modify
//      it under the terms of the GNU General Public License as published by
//      the Free Software Foundation; either version 2 of the License, or
//      (at your option) any later version.
//      
//      This program is distributed in the hope that it will be useful,
//      but WITHOUT ANY WARRANTY; without even the implied warranty of
//      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//      GNU General Public License for more details.
//      
//      You should have received a copy of the GNU General Public License
//      along with this program; if not, write to the Free Software
//      Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
//      MA 02110-1301, USA.

#include "glib.h"
#include "s65.h"



// Font 5x5 ( largura da fonte n�o � fixa )
extern const u8 Font5x5[289] = {
0, 				// Code for char Espa�o   
23, 			// Code for char !  
3,0,3, 			// Code for char "  
10,31,10,31,10, // Code for char #  
4,14,27,10, 	// Code for char $  
9,4,2,9, 		// Code for char %  
10,21,17, 		// Code for char &  
3,4, 			// Code for char '  
14,27,17, 		// Code for char (  
17,27,14, 		// Code for char )  
21,14,14,21, 	// Code for char *  
4,14,4, 		// Code for char +  
16,8, 			// Code for char ,  
4,4,4, 			// Code for char -  
16, 			// Code for char .  
16,12,3, 		// Code for char "/"  
31,17,31, 		// Code for char 0  
18,31,16, 		// Code for char 1  
25,21,18, 		// Code for char 2  
17,21,14, 		// Code for char 3  
14,8,30, 		// Code for char 4  
23,21,9, 		// Code for char 5  
31,21,29, 		// Code for char 6  
18,10,6, 		// Code for char 7  
10,21,10, 		// Code for char 8  
23,21,31, 		// Code for char 9  
10, 			// Code for char :  
16,10, 			// Code for char ;  
4,10,17, 		// Code for char <  
10,10,10, 		// Code for char =  
17,10,4, 		// Code for char >  
1,21,2, 		// Code for char ?  
14,19,22, 		// Code for char @  
30,9,30, 		// Code for char A  
31,21,10, 		// Code for char B  
14,17,17, 		// Code for char C  
31,17,14, 		// Code for char D  
31,21,21, 		// Code for char E  
31,5,5, 		// Code for char F  
14,17,29, 		// Code for char G  
31,4,31, 		// Code for char H  
17,31,17, 		// Code for char I  
24,16,31, 		// Code for char J  
31,4,27, 		// Code for char K  
31,16,16, 		// Code for char L  
31,2,4,2,31, 	// Code for char M  
31,1,30, 		// Code for char N  
14,17,14, 		// Code for char O  
31,5,2, 		// Code for char P  
31,17,31,16, 	// Code for char Q  
31,5,26, 		// Code for char R  
18,21,9, 		// Code for char S  
1,31,1, 		// Code for char T  
15,16,15, 		// Code for char U  
31,8,7, 		// Code for char V  
15,16,12,16,15, // Code for char W  
27,4,27, 		// Code for char X  
3,28,3, 		// Code for char Y  
25,21,19, 		// Code for char Z  
31,17,17, 		// Code for char [  
1,6,24, 		// Code for char "\"  
17,17,31, 		// Code for char ]  
2,1,2, 			// Code for char ^  
16,16,16, 		// Code for char _  
1,2, 			// Code for char `  
8,26,28, 		// Code for char a  
31,20,8, 		// Code for char b  
12,18,18, 		// Code for char c  
8,20,31, 		// Code for char d  
12,22,20, 		// Code for char e  
30,5,1, 		// Code for char f  
20,26,12, 		// Code for char g  
31,4,24, 		// Code for char h  
29, 			// Code for char i  
16,16,13, 		// Code for char j  
31,8,20, 		// Code for char k  
17,31,16, 		// Code for char l  
30,2,12,2,28, 	// Code for char m  
30,2,28, 		// Code for char n  
12,18,12, 		// Code for char o  
30,10,4, 		// Code for char p  
4,10,30, 		// Code for char q  
30,4,2, 		// Code for char r  
20,22,10, 		// Code for char s  
4,30,4, 		// Code for char t  
14,16,14, 		// Code for char u  
30,8,6, 		// Code for char v  
14,16,12,16,14, // Code for char w  
18,12,18, 		// Code for char x  
22,20,14, 		// Code for char y  
26,22,22, 		// Code for char z  
4,14,17, 		// Code for char {  
27, 			// Code for char |  
17,14,4, 		// Code for char }  
1,2,1,2, 		// Code for char ~  
14,14,14,14 	// Code for char " "
};

// Char position and char size table
//
// CharSize = Font5x5WidthPos["2"] - Font5x5WidthPos["2" - 1]
// CharPos  = Font5x5WidthPos["2" - 1]
//
extern const u16 Font5x5WidthPos[96] = {
1,2,5,10,14,18,21,23,26,29,33,36,38,41,
42,45,48,51,54,57,60,63,66,69,72,75,76,
78,81,84,87,90,93,96,99,102,105,108,111,
114,117,120,123,126,129,134,137,140,143,
147,150,153,156,159,162,167,170,173,176,
179,182,185,188,191,193,196,199,202,205,
208,211,214,217,218,221,224,227,232,235,
238,241,244,247,250,253,256,259,264,267,
270,273,276,277,280,284,289
};

extern const u8 batt[] = {
	0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0,
	1,1,1,1,1,1,1,1,1,0,
	1,0,0,0,0,0,0,0,1,0,
	1,0,0,0,0,0,0,0,1,1,
	1,0,0,0,0,0,0,0,1,1,
	1,0,0,0,0,0,0,0,1,0,
	1,1,1,1,1,1,1,1,1,0,
	0,0,0,0,0,0,0,0,0,0,
	0,0,0,0,0,0,0,0,0,0
	};

	
extern const u16 pot10[4] ={10,100,1000,10000};

unsigned int CursorX;
unsigned int CursorY;
u8 DisplayActive = 0;


void GLib_Init() {	
	LCD_Init();
	CursorX = 0;
	CursorY = 12;
	DisplayActive = 0;
}


void Fill(u16 color) {
	u16 i;
	
	if (DisplayActive == 1) return;
	DisplayActive = 1;
	
	LCD_SetArea(0, 0, LCD_WIDTH-1, LCD_HEIGHT-1);
	
	LCD_SendCMD(RAMWR);
	
	// start data transmission  
	for (i=0; i<LCD_WIDTH*LCD_HEIGHT; i++) {
		LCD_SendDAT16(color);
	}
	DisplayActive = 0;
}

void FillM() {
	u16 i,ii;
	u16 color1 = RGB(255,255,255), color2 = RGB(100,100,100);
	u8 b = 0;
	
	if (DisplayActive == 1) return;
	DisplayActive = 1;
	
	LCD_SetArea(0, 0, LCD_WIDTH-1, LCD_HEIGHT-1);
	
	LCD_SendCMD(RAMWR);
	
	// start data transmission  
	for (i = 0; i < LCD_WIDTH; i++) {
		for (ii = 0; ii < LCD_HEIGHT / 2; ii++) {
			if ( b == 0 ) {
				LCD_SendDAT16(color1);
				LCD_SendDAT16(color2);								
			} else {
				LCD_SendDAT16(color2);
				LCD_SendDAT16(color1);				
			}
		}
		if ( b == 0 ) b = 1;
		else b = 0;
	}
	DisplayActive = 0;
}

u8 GetCharWidth(const char character) {
	u8 fontIndex, fontPos = 0;
	
	fontIndex = character - 32;
	if ( character < 32 ) return 0;
	if ( fontIndex > 96 ) return 0;
	
	if ( fontIndex > 0 ) {
		fontPos = Font5x5WidthPos[ fontIndex - 1];
	}
	return (Font5x5WidthPos[ fontIndex ] - fontPos);
}

/*
*	Draw a Char
*/
u8 DrawChar5x5(u8 x, u8 y, const char character, u16 color, u16 bgcolor) {
	u16 i, j, fontWidth, fontPos = 0, fontIndex;	
	
	fontWidth = GetCharWidth(character);
	
	if (fontWidth == 0) return 0;
	
	fontIndex = character - 32;
	
	if ( fontIndex > 0 ) {
		fontPos = Font5x5WidthPos[ fontIndex - 1];
	}
	
	LCD_SetArea(x, y, x + fontWidth + 1, y + 5);
    LCD_SendCMD(RAMWR);
	for (i = 0; i < fontWidth; i++) {
		for (j = 0; j <= 5; j++) {      
			if ( ValBit( Font5x5[ fontPos + i ], j ) ) {				
				LCD_SendDAT16(color);
			} else {
				LCD_SendDAT16(bgcolor);
			}
		}	   
	}
	for (j = 0; j <= 5; j++) { 
		LCD_SendDAT16(bgcolor);
	}
	fontWidth++;
	return fontWidth;
}

unsigned int Puts(u8 x, u8 y, const char *s, u8 font, u16 color, u16 bgcolor) {
	char c;

	if (DisplayActive == 1) return;
	DisplayActive = 1;
	
	while(*s) {
		c = *s++;
		if(c >= 0x20) {
			//if ( font == FONT5x5 ) {
				x = x + DrawChar5x5(x, y, c, color, bgcolor);
			//} else if ( font == FONT5x7 ) {
			//	x = x + DrawChar5x7(x, y, c, color, bgcolor);
			//}
			if(x > LCD_WIDTH) {
				break;
			}
		}
	}
	
	DisplayActive = 0;
	return x;
}

void FillRect(u8 x0, u8 y0, u8 x1, u8 y1, u16 color) {
	unsigned int wh, tmp;	
	
	if(x0 > x1) {
		tmp = x0;
		x0  = x1;
		x1  = tmp;
	}
  
	if(y0 > y1) {
		tmp = y0;
		y0  = y1;
		y1  = tmp;
	}

	if((x1 >= LCD_WIDTH) ||
		(y1 >= LCD_HEIGHT)) {		
		return;
	}

	if (DisplayActive == 1) return;
	DisplayActive = 1;
	
	LCD_SetArea(x0, y0, x1, y1);

	LCD_SendCMD(RAMWR);
	for(wh=((1+(x1-x0))*(1+(y1-y0))); wh!=0; wh--) {
		LCD_SendDAT16(color);
	}

	DisplayActive = 0;
}

void DrawLine(u8 x0, u8 y0, u8 x1, u8 y1, u16 color) {
	
	int dx, dy, dx2, dy2, stepx, stepy, err;

	if (DisplayActive == 1) return;
	DisplayActive = 1;
	
	if((x0 == x1) ||
		(y0 == y1)) //horizontal or vertical line
	{
		FillRect(x0, y0, x1, y1, color);
	} else {
		//calculate direction
		dx = x1 - x0;
		dy = y1 - y0;
		if(dx < 0) { dx = -dx; stepx = -1; } else { stepx = +1; }
		if(dy < 0) { dy = -dy; stepy = -1; } else { stepy = +1; }
		dx2 = dx << 1;
		dy2 = dy << 1;
		//draw line
		//LCD_SetArea(0, 0, (LCD_WIDTH-1), (LCD_HEIGHT-1));
		LCD_DrawPixel(x0, y0, color);
		if(dx > dy) {
			err = dy2 - dx;
			while(x0 != x1) {
				if(err >= 0) {
					err -= dx2;
					y0  += stepy;
				}
				err += dy2;
				x0  += stepx;
				LCD_DrawPixel(x0, y0, color);
			}
		} else {
			err = dx2 - dy;
			while(y0 != y1) {
				if(err >= 0) {
					err -= dy2;
					x0  += stepx;
				}
				err += dx2;
				y0  += stepy;
				LCD_DrawPixel(x0, y0, color);
			}
		}
	}
	DisplayActive = 0;
}

void u16tostr( u16 val,  char *strg, u8 nzero) {
/*
  convert unsigned int16 value to a character string
  stringlength has to be 6 character 65536 + the final 0
  
  if nzero==0, no leading zeros
  if nzero==1, with leading zeros  
*/
	u8 dec,idx=4,odx=0;
	
	do {
		idx--;
		for (dec=0; val>=pot10[idx]; val-=pot10[idx]) {
			dec++;
		}
		nzero+=dec;
		if (nzero) strg[odx++] = '0' + dec;
	} while(idx);
	strg[odx++]='0'+val;
	strg[odx]=0;
}


void DrawIcon(u8 x, u8 y, u8 icon[]) {
	u8 i,ii;
	u16 color1 = WHITE, color2 = BLACK;
	
	if (DisplayActive == 1) return;
	DisplayActive = 1;
	
	LCD_SetArea(x, y, x + 10, y + 10);
	
	LCD_SendCMD(RAMWR);
	
	// start data transmission  
	for (i = 0; i < 10; i++) {
		for (ii = 0; ii <= 10; ii++) {
			if ( icon[(ii*10) + i] == 1 ) {
				LCD_SendDAT16(color1);
			} else {
				LCD_SendDAT16(color2);
			}			
		}
	}
	DisplayActive = 0;
}


// Set the position of the cursor to print 
void GotoXY( u16 x, u16 y ) {	
	CursorX = x;
	CursorY = y;
}

void BackChar(const char c) {
	u8 charw;
	charw = GetCharWidth(c);
	CursorX = CursorX - charw - 1;
	FillRect(CursorX, CursorY, CursorX + charw, CursorY + 5, RGB(255,255,255));
	
}

void Cls(void) {
	FillRect(0, 11, LCD_WIDTH - 1, LCD_HEIGHT - 1, RGB(255,255,255));
	GotoXY( 0, 12 );
}

void DrawChar(char c, u16 color, u16 bgcolor) {
	u8 fontWidth;

	u8 x = CursorX;
	u8 y = CursorY;
	
	/* If the character is a newline, then prepare our x and y
	 * coordinates for the next character on the new line. */
	if (c == '\n') {
		/* Reset x to its origin */
		x = 0;
		/* Move y one character down */	
		if ((y + 8) >= LCD_HEIGHT) {
			y = 12;
			Cls();
		} else {
			y += 6;
		}
	} else { 
		if ((x + 6) > LCD_WIDTH) {
			x = 0;				
			if ((y + 6) >= LCD_HEIGHT) {
				y = 12;
				Cls();
			} else {
				y += 6;
			}
		}
		fontWidth = DrawChar5x5(x, y, c, color, bgcolor);
		x += fontWidth;
	}
	GotoXY( x, y );
}

void Write(const char *s, u8 font, u16 color, u16 bgcolor) {
	char c;
	if (DisplayActive == 1) return;
	DisplayActive = 1;
	
	while(*s) {
		c = *s++;
		if(c >= 0x20) {
				DrawChar(c, color, bgcolor);
		}
	}
	DisplayActive = 0;
}